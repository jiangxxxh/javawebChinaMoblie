CREATE VIEW VIEW_EMP1 AS
  select d.dname,e."EMPNO",e."ENAME",e."JOB",e."MGR",e."HIREDATE",e."SAL",e."COMM",e."DEPTNO" from emp e,dept d where e.deptno=d.deptno and d.deptno in (10,30)
/

