CREATE VIEW VIEW_EMP AS
  select rownum rn,emp."EMPNO",emp."ENAME",emp."JOB",emp."MGR",emp."HIREDATE",emp."SAL",emp."COMM",emp."DEPTNO" from emp where ename like 'A%' or ename like 'S%'
/

