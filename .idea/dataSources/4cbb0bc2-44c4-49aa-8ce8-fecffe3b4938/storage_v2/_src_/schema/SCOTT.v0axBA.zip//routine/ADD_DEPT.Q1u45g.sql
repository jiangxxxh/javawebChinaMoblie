CREATE procedure add_dept(deptnum in number,deptname in varchar2)
is
begin
  insert into dept(deptno,dname) values (deptnum,deptname);
end;
/

