CREATE VIEW VIEW_EMP2 AS
  select job,round(avg(nvl(sal,0)),2) avg_sal,sum(sal) sum_sal,max(sal) max_sal,min(sal) min_sal
from emp
group by job
/

